<?php
/** no direct access **/
defined('MECEXEC') or die();
?>
<div class="mec-calendar-metabox mec-shortcode">[MEC id="<?php echo $post->ID; ?>"]</div>